-- Adminer 3.7.1 MySQL dump

SET NAMES utf8;
SET foreign_key_checks = 0;
SET time_zone = '+02:00';
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `binding`;
CREATE TABLE `binding` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transport_id` int(11) NOT NULL,
  `payment_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `transport_id` (`transport_id`),
  KEY `payment_id` (`payment_id`),
  CONSTRAINT `binding_ibfk_1` FOREIGN KEY (`transport_id`) REFERENCES `transport` (`id`),
  CONSTRAINT `binding_ibfk_2` FOREIGN KEY (`payment_id`) REFERENCES `payment` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

INSERT INTO `binding` (`id`, `transport_id`, `payment_id`) VALUES
(1,	2,	1),
(2,	2,	2),
(3,	1,	3),
(4,	1,	1),
(5,	1,	2),
(6,	2,	3);

DROP TABLE IF EXISTS `order`;
CREATE TABLE `order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `products_id` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `intenal_id` varchar(100) COLLATE utf8_czech_ci NOT NULL,
  `variableSymbol` varchar(100) COLLATE utf8_czech_ci NOT NULL,
  `count` int(11) NOT NULL,
  `reason` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `products_id` (`products_id`),
  CONSTRAINT `order_ibfk_1` FOREIGN KEY (`products_id`) REFERENCES `products` (`id`) ON DELETE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

INSERT INTO `order` (`id`, `products_id`, `status`, `intenal_id`, `variableSymbol`, `count`, `reason`) VALUES
(1,	1,	0,	'',	'',	0,	6),
(2,	1,	1,	'',	'',	0,	0),
(3,	1,	0,	'',	'',	0,	0),
(4,	1,	0,	'',	'',	0,	0),
(5,	2,	1,	'',	'',	0,	0),
(6,	2,	4,	'',	'',	0,	0),
(7,	3,	1,	'',	'',	0,	0),
(8,	3,	0,	'',	'',	0,	0),
(10,	1,	0,	'16044',	'18293',	1,	0),
(11,	1,	0,	'17162',	'18299',	1,	6),
(18,	2,	0,	'7732',	'25693',	1,	0);

DROP TABLE IF EXISTS `payment`;
CREATE TABLE `payment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_czech_ci NOT NULL,
  `price` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

INSERT INTO `payment` (`id`, `type`, `name`, `price`) VALUES
(1,	2,	'PPL',	120),
(2,	1,	'PPL',	4500),
(3,	3,	'PPL',	12.99);

DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` varchar(32) COLLATE utf8_czech_ci NOT NULL,
  `available` int(11) NOT NULL,
  `delivery` varchar(100) COLLATE utf8_czech_ci NOT NULL,
  `name` varchar(100) COLLATE utf8_czech_ci NOT NULL,
  `price` float NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `item_id` (`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

INSERT INTO `products` (`id`, `item_id`, `available`, `delivery`, `name`, `price`) VALUES
(1,	'abc1',	1,	'1',	'tést',	100),
(2,	'abc2',	1,	'1',	'tést',	100),
(3,	'abc3',	1,	'1',	'teést',	100),
(4,	'abc4',	1,	'1',	'teést',	200),
(5,	'abc5',	1,	'1',	'teést',	100),
(6,	'abc6',	1,	'1',	'teést',	200);

DROP TABLE IF EXISTS `products_params`;
CREATE TABLE `products_params` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `products_id` int(11) NOT NULL,
  `typ` varchar(100) COLLATE utf8_czech_ci NOT NULL,
  `name` varchar(100) COLLATE utf8_czech_ci NOT NULL,
  `unit` varchar(100) COLLATE utf8_czech_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `products_id` (`products_id`),
  CONSTRAINT `products_params_ibfk_1` FOREIGN KEY (`products_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

INSERT INTO `products_params` (`id`, `products_id`, `typ`, `name`, `unit`) VALUES
(1,	1,	'input',	'Délka',	'm'),
(2,	1,	'input',	'Délka',	''),
(3,	3,	'input',	'Délka',	'kg'),
(4,	3,	'input',	'Délka',	'kg');

DROP TABLE IF EXISTS `products_related`;
CREATE TABLE `products_related` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `products_id` int(11) NOT NULL,
  `title` varchar(100) COLLATE utf8_czech_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `products_id` (`products_id`),
  CONSTRAINT `products_related_ibfk_1` FOREIGN KEY (`products_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

INSERT INTO `products_related` (`id`, `products_id`, `title`) VALUES
(1,	1,	'Zdarma dárková taška'),
(2,	1,	'test'),
(3,	2,	'Zdarma dárková taška');

DROP TABLE IF EXISTS `products_related_values`;
CREATE TABLE `products_related_values` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `products_related_id` int(11) NOT NULL,
  `default` int(11) NOT NULL,
  `value` varchar(255) COLLATE utf8_czech_ci NOT NULL,
  `price` float NOT NULL,
  PRIMARY KEY (`id`),
  KEY `products_related_id` (`products_related_id`),
  CONSTRAINT `products_related_values_ibfk_1` FOREIGN KEY (`products_related_id`) REFERENCES `products_related` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

INSERT INTO `products_related_values` (`id`, `products_related_id`, `default`, `value`, `price`) VALUES
(1,	1,	1,	'cervena',	10.6),
(2,	1,	0,	'cervena',	10.6),
(3,	2,	1,	'cervena',	10.6);

DROP TABLE IF EXISTS `store`;
CREATE TABLE `store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transport_id` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `transport_id` (`transport_id`),
  CONSTRAINT `store_ibfk_1` FOREIGN KEY (`transport_id`) REFERENCES `transport` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

INSERT INTO `store` (`id`, `transport_id`, `type`) VALUES
(1,	1,	1),
(4,	2,	1),
(5,	2,	2);

DROP TABLE IF EXISTS `transport`;
CREATE TABLE `transport` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_czech_ci NOT NULL,
  `price` float NOT NULL,
  `description` varchar(100) COLLATE utf8_czech_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

INSERT INTO `transport` (`id`, `type`, `name`, `price`, `description`) VALUES
(1,	1,	'PPL',	120,	'Do 1 - 2 dnů'),
(2,	1,	'PPL',	120,	'Do 1 - 2 dnů');

-- 2013-07-25 01:53:13
